# PROFESIONAL_C171
Código de referencia para PROFESIONAL_C171

Flujo de la app:
1. Abre la app usando ngrok.
2. Escanea el marcador del platillo.
3. Añade el número de mesa.
4. Toma la orden para el número de mesa en particular al hacer clic en el botón "ORDENAR".

Nota: recarga la app si se cerró la alerta para ingresar el número de mesa antes de ingresar el dato.
